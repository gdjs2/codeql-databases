int f(int x) {
	return x+1;
}

void vul(int x) {
	// vul
}

int main() {
	int a, b;
	int c = a+b;
	int d = f(a);
	int e = d + 10;
	vul(e);
	return 0;
}